Permafrost Map
    Permafrost distribution in the baseline period (2006-2015)
    1: permafrost, 2: non-permafrost
ALT Map
    Active layer thickness in the baseline period (2006-2015)
    unit: m
SOC Map
    0-3 m Soil organic carbon distribution in the baseline period (2006-2015)
    unit: kg/m^2
TP Scope:
    shp file for the scope of Tibetan Plateau